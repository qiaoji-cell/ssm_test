create definer = root@localhost view view_stu_record_eat as
select `sr`.`id`                                     AS `studentId`,
       `sr`.`student_name`                           AS `studentName`,
       `sr`.`student_code`                           AS `studentCode`,
       `sr`.`gender`                                 AS `studentGender`,
       `g`.`gradeName`                               AS `studentGradeName`,
       `g`.`id`                                      AS `studentGradeId`,
       `c`.`className`                               AS `studentClassName`,
       `c`.`id`                                      AS `studentClassId`,
       '1997-01-01'                                  AS `studentChargeStartDate`,
       '1997-01-01'                                  AS `studentChargeEndDate`,
       `kcc`.`costName`                              AS `studentChargeCategoryName`,
       `groove`.`groove_name`                        AS `studentChargeGrooveName`,
       `groove`.`cost_type`                          AS `studentChargeCostType`,
       `groove`.`univalence`                         AS `studentChargeUnivalence`,
       `groove`.`univalence_type`                    AS `studentChargeUnivalenceType`,
       `groove`.`pay_type`                           AS `studentChargePayType`,
       `groove`.`refund`                             AS `studentChargeRefund`,
       `groove`.`alone`                              AS `studentIsAlone`,
       `sr`.`enter_date`                             AS `studentEnterDate`,
       `sr`.`garden_id`                              AS `studentGardenId`,
       concat(year(now()), '-', month(now()), '-01') AS `studentFeeDate`,
       1                                             AS `studentState`
from (((((`kms_db`.`kms_student_record` `sr` left join `kms_db`.`kms_stu_record_eat_care` `sre` on ((`sre`.`stu_id` = `sr`.`id`))) left join `kms_db`.`kms_grade` `g` on ((`sr`.`grade_id` = `g`.`id`))) left join `kms_db`.`kms_class` `c` on ((`sr`.`classroom_id` = `c`.`id`))) left join `kms_db`.`kms_groove` `groove` on ((`groove`.`id` = `sre`.`now_eat_id`)))
         left join `kms_db`.`kms_cost_category` `kcc` on ((`kcc`.`id` = `groove`.`cost_category`)))
where (`kcc`.`costName` is not null);

-- comment on column view_stu_record_eat.studentId not supported: 编号

-- comment on column view_stu_record_eat.studentName not supported: 学生姓名

-- comment on column view_stu_record_eat.studentCode not supported: 学生编号

-- comment on column view_stu_record_eat.studentGender not supported: 学生性别

-- comment on column view_stu_record_eat.studentGradeName not supported: 年级名称

-- comment on column view_stu_record_eat.studentGradeId not supported: 编号

-- comment on column view_stu_record_eat.studentClassName not supported: 班级名称

-- comment on column view_stu_record_eat.studentClassId not supported: 编号

-- comment on column view_stu_record_eat.studentChargeCategoryName not supported: 类目名称

-- comment on column view_stu_record_eat.studentChargeGrooveName not supported: 费项名称

-- comment on column view_stu_record_eat.studentChargeCostType not supported: 1 保育费 2.伙食费 3.其他费项

-- comment on column view_stu_record_eat.studentChargeUnivalence not supported: 收费单价

-- comment on column view_stu_record_eat.studentChargeUnivalenceType not supported: 收费方式 1.代表按学期、2.代表按月、3.代表按天

-- comment on column view_stu_record_eat.studentChargePayType not supported: 1 预付费 2.后付费(已【本月考勤】收本月保育费伙食费) 3.后付费(以【上月考勤】收本月保育费/伙食费)

-- comment on column view_stu_record_eat.studentChargeRefund not supported: 退费单价

-- comment on column view_stu_record_eat.studentIsAlone not supported: 单独打印 （0.代付否、1.代表是）

-- comment on column view_stu_record_eat.studentEnterDate not supported: 正式入园时间

-- comment on column view_stu_record_eat.studentGardenId not supported: 所属园所

