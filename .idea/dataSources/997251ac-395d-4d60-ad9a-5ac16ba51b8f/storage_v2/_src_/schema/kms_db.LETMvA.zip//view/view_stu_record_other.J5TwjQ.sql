create definer = root@localhost view view_stu_record_other as
select `ksr`.`id`                                    AS `studentId`,
       `ksr`.`student_name`                          AS `studentName`,
       `ksr`.`student_code`                          AS `studentCode`,
       `ksr`.`gender`                                AS `studentGender`,
       `kg`.`gradeName`                              AS `studentGradeName`,
       `kg`.`id`                                     AS `studentGradeId`,
       `kc`.`className`                              AS `studentClassName`,
       `kc`.`id`                                     AS `studentClassId`,
       `ksro`.`start_date`                           AS `studentChargeStartDate`,
       `ksro`.`end_date`                             AS `studentChargeEndDate`,
       `kcc`.`costName`                              AS `studentChargeCategoryName`,
       `g`.`groove_name`                             AS `studentChargeGrooveName`,
       `g`.`cost_type`                               AS `studentChargeCostType`,
       `g`.`univalence`                              AS `studentChargeUnivalence`,
       `g`.`univalence_type`                         AS `studentChargeUnivalenceType`,
       `g`.`pay_type`                                AS `studentChargePayType`,
       `g`.`refund`                                  AS `studentChargeRefund`,
       `g`.`alone`                                   AS `studentIsAlone`,
       `ksr`.`enter_date`                            AS `studentEnterDate`,
       `ksr`.`garden_id`                             AS `studentGardenId`,
       concat(year(now()), '-', month(now()), '-01') AS `studentFeeDate`,
       1                                             AS `studentState`
from (((((`kms_db`.`kms_stu_record_other` `ksro` left join `kms_db`.`kms_groove` `g` on ((`g`.`id` = `ksro`.`groove_cost_id`))) left join `kms_db`.`kms_cost_category` `kcc` on ((`g`.`cost_category` = `kcc`.`id`))) left join `kms_db`.`kms_student_record` `ksr` on ((`ksr`.`id` = `ksro`.`stu_id`))) left join `kms_db`.`kms_class` `kc` on ((`kc`.`id` = `ksr`.`classroom_id`)))
         left join `kms_db`.`kms_grade` `kg` on ((`kg`.`id` = `ksr`.`grade_id`)))
where (`kcc`.`costName` is not null);

-- comment on column view_stu_record_other.studentId not supported: 编号

-- comment on column view_stu_record_other.studentName not supported: 学生姓名

-- comment on column view_stu_record_other.studentCode not supported: 学生编号

-- comment on column view_stu_record_other.studentGender not supported: 学生性别

-- comment on column view_stu_record_other.studentGradeName not supported: 年级名称

-- comment on column view_stu_record_other.studentGradeId not supported: 编号

-- comment on column view_stu_record_other.studentClassName not supported: 班级名称

-- comment on column view_stu_record_other.studentClassId not supported: 编号

-- comment on column view_stu_record_other.studentChargeStartDate not supported: 费用开始日期

-- comment on column view_stu_record_other.studentChargeEndDate not supported: 费用结束日期

-- comment on column view_stu_record_other.studentChargeCategoryName not supported: 类目名称

-- comment on column view_stu_record_other.studentChargeGrooveName not supported: 费项名称

-- comment on column view_stu_record_other.studentChargeCostType not supported: 1 保育费 2.伙食费 3.其他费项

-- comment on column view_stu_record_other.studentChargeUnivalence not supported: 收费单价

-- comment on column view_stu_record_other.studentChargeUnivalenceType not supported: 收费方式 1.代表按学期、2.代表按月、3.代表按天

-- comment on column view_stu_record_other.studentChargePayType not supported: 1 预付费 2.后付费(已【本月考勤】收本月保育费伙食费) 3.后付费(以【上月考勤】收本月保育费/伙食费)

-- comment on column view_stu_record_other.studentChargeRefund not supported: 退费单价

-- comment on column view_stu_record_other.studentIsAlone not supported: 单独打印 （0.代付否、1.代表是）

-- comment on column view_stu_record_other.studentEnterDate not supported: 正式入园时间

-- comment on column view_stu_record_other.studentGardenId not supported: 所属园所

