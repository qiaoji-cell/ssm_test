create definer = root@localhost view view_stu_record_care as
select `sr`.`id`                                     AS `studentId`,
       `sr`.`student_name`                           AS `studentName`,
       `sr`.`student_code`                           AS `studentCode`,
       `sr`.`gender`                                 AS `studentGender`,
       `g`.`gradeName`                               AS `studentGradeName`,
       `g`.`id`                                      AS `studentGradeId`,
       `c`.`className`                               AS `studentClassName`,
       `c`.`id`                                      AS `studentClassId`,
       '1997-01-01'                                  AS `studentChargeStartDate`,
       '1997-01-01'                                  AS `studentChargeEndDate`,
       `kcc`.`costName`                              AS `studentChargeCategoryName`,
       `groove`.`groove_name`                        AS `studentChargeGrooveName`,
       `groove`.`cost_type`                          AS `studentChargeCostType`,
       `groove`.`univalence`                         AS `studentChargeUnivalence`,
       `groove`.`univalence_type`                    AS `studentChargeUnivalenceType`,
       `groove`.`pay_type`                           AS `studentChargePayType`,
       `groove`.`refund`                             AS `studentChargeRefund`,
       `groove`.`alone`                              AS `studentIsAlone`,
       `sr`.`enter_date`                             AS `studentEnterDate`,
       `sr`.`garden_id`                              AS `studentGardenId`,
       concat(year(now()), '-', month(now()), '-01') AS `studentFeeDate`,
       1                                             AS `studentState`
from (((((`kms_db`.`kms_student_record` `sr` left join `kms_db`.`kms_stu_record_eat_care` `sre` on ((`sre`.`stu_id` = `sr`.`id`))) left join `kms_db`.`kms_grade` `g` on ((`sr`.`grade_id` = `g`.`id`))) left join `kms_db`.`kms_class` `c` on ((`sr`.`classroom_id` = `c`.`id`))) left join `kms_db`.`kms_groove` `groove` on ((`groove`.`id` = `sre`.`now_care_id`)))
         left join `kms_db`.`kms_cost_category` `kcc` on ((`kcc`.`id` = `groove`.`cost_category`)))
where (`kcc`.`costName` is not null);

-- comment on column view_stu_record_care.studentId not supported: 编号

-- comment on column view_stu_record_care.studentName not supported: 学生姓名

-- comment on column view_stu_record_care.studentCode not supported: 学生编号

-- comment on column view_stu_record_care.studentGender not supported: 学生性别

-- comment on column view_stu_record_care.studentGradeName not supported: 年级名称

-- comment on column view_stu_record_care.studentGradeId not supported: 编号

-- comment on column view_stu_record_care.studentClassName not supported: 班级名称

-- comment on column view_stu_record_care.studentClassId not supported: 编号

-- comment on column view_stu_record_care.studentChargeCategoryName not supported: 类目名称

-- comment on column view_stu_record_care.studentChargeGrooveName not supported: 费项名称

-- comment on column view_stu_record_care.studentChargeCostType not supported: 1 保育费 2.伙食费 3.其他费项

-- comment on column view_stu_record_care.studentChargeUnivalence not supported: 收费单价

-- comment on column view_stu_record_care.studentChargeUnivalenceType not supported: 收费方式 1.代表按学期、2.代表按月、3.代表按天

-- comment on column view_stu_record_care.studentChargePayType not supported: 1 预付费 2.后付费(已【本月考勤】收本月保育费伙食费) 3.后付费(以【上月考勤】收本月保育费/伙食费)

-- comment on column view_stu_record_care.studentChargeRefund not supported: 退费单价

-- comment on column view_stu_record_care.studentIsAlone not supported: 单独打印 （0.代付否、1.代表是）

-- comment on column view_stu_record_care.studentEnterDate not supported: 正式入园时间

-- comment on column view_stu_record_care.studentGardenId not supported: 所属园所

